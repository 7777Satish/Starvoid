Hello,

Thanks for downloading 
simple installation, ONE KLIK to install

Please follow our instagram for update : @glyphstyle

adn visit our website https://www.glyphstyle.net/



How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

How to Using Special Characters

https://helpx.adobe.com/illustrator/using/special-characters.html

Thanks,


GlyphStyle